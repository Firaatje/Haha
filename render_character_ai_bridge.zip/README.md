# Character.AI Bridge voor WhatsApp

## Hoe gebruiken op Render.com

1. Maak een nieuwe Web Service op [https://render.com](https://render.com)
2. Upload deze ZIP of koppel je GitHub
3. Stel de volgende environment variables in:
   - EMAIL = je login van Character.AI
   - PASSWORD = je wachtwoord

4. Render geeft je een URL zoals: `https://fira-characterai.onrender.com`

5. POST naar `/ask` met JSON:
```json
{ "message": "Hallo!" }
```

De server antwoordt met het antwoord van jouw bot.
